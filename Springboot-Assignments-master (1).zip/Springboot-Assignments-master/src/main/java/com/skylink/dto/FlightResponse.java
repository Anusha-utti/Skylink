package com.skylink.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.skylink.entity.FlightStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FlightResponse {
    private Long id;
    private String flightNumber;
    private String airline;
    private String sourceAirport;
    private String destinationAirport;
    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;
    private Integer totalSeats;
    private Integer availableSeats;
    private BigDecimal farePerSeat;
    private FlightStatus status;
    private Long durationMinutes;
}