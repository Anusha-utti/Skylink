package com.skylink.dto;

import com.skylink.entity.Gender;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PassengerResponse {
    private Long id;
    private String name;
    private Integer age;
    private Gender gender;
    private String idProof;
    private String idProofNumber;
}