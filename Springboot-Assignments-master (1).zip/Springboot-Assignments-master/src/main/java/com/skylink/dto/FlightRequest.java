package com.skylink.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class FlightRequest {
    @NotBlank(message = "Flight number is required")
    private String flightNumber;
    
    @NotBlank(message = "Airline is required")
    private String airline;
    
    @NotBlank(message = "Source airport is required")
    private String sourceAirport;
    
    @NotBlank(message = "Destination airport is required")
    private String destinationAirport;
    
    @NotNull(message = "Departure time is required")
    private LocalDateTime departureTime;
    
    @NotNull(message = "Arrival time is required")
    private LocalDateTime arrivalTime;
    
    @NotNull(message = "Total seats is required")
    @Min(value = 1, message = "Total seats must be at least 1")
    private Integer totalSeats;
    
    @NotNull(message = "Fare per seat is required")
    @DecimalMin(value = "0.01", message = "Fare must be greater than 0")
    private BigDecimal farePerSeat;
}