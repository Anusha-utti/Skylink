package com.skylink.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class PaymentRequest {
    @NotBlank(message = "PNR is required")
    private String pnr;
    
    private String paymentMethod;
}