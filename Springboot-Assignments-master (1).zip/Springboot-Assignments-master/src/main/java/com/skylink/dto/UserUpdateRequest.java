package com.skylink.dto;

import lombok.Data;

@Data
public class UserUpdateRequest {
    private String name;
    private String phone;
}