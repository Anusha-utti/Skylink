package com.skylink.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class FlightSearchRequest {
    @NotBlank(message = "Source airport is required")
    private String source;
    
    @NotBlank(message = "Destination airport is required")
    private String destination;
    
    @NotNull(message = "Journey date is required")
    private LocalDate journeyDate;
    
    private String airline;
}