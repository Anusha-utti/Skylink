package com.skylink.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.skylink.entity.BookingStatus;
import com.skylink.entity.PaymentStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingResponse {
    private Long id;
    private String pnr;
    private Long userId;
    private String userName;
    private FlightResponse flight;
    private List<PassengerResponse> passengers;
    private Integer numberOfSeats;
    private BigDecimal totalAmount;
    private BookingStatus status;
    private PaymentStatus paymentStatus;
    private LocalDateTime bookingDate;
}
