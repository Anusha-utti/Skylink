package com.skylink.dto;

import com.skylink.entity.Gender;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class PassengerRequest {
    @NotBlank(message = "Passenger name is required")
    private String name;
    
    @NotNull(message = "Age is required")
    @Min(value = 1, message = "Age must be at least 1")
    private Integer age;
    
    @NotNull(message = "Gender is required")
    private Gender gender;
    
    @NotBlank(message = "ID proof type is required")
    private String idProof;
    
    @NotBlank(message = "ID proof number is required")
    private String idProofNumber;
}
