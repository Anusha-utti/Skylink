package com.skylink.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skylink.dto.BookingRequest;
import com.skylink.dto.BookingResponse;
import com.skylink.dto.FlightResponse;
import com.skylink.dto.PassengerRequest;
import com.skylink.dto.PassengerResponse;
import com.skylink.dto.PaymentRequest;
import com.skylink.entity.Booking;
import com.skylink.entity.BookingStatus;
import com.skylink.entity.Flight;
import com.skylink.entity.FlightStatus;
import com.skylink.entity.Passenger;
import com.skylink.entity.PaymentStatus;
import com.skylink.entity.User;
import com.skylink.exception.InsufficientSeatsException;
import com.skylink.exception.InvalidRequestException;
import com.skylink.exception.ResourceNotFoundException;
import com.skylink.repository.BookingRepository;
import com.skylink.repository.FlightRepository;
import com.skylink.repository.PassengerRepository;
import com.skylink.repository.UserRepository;

@Service
public class BookingService {
    
    private static final Logger logger = LoggerFactory.getLogger(BookingService.class);
    
    @Autowired
    private BookingRepository bookingRepository;
    
    @Autowired
    private FlightRepository flightRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PassengerRepository passengerRepository;
    
    @Transactional
    public BookingResponse createBooking(BookingRequest request) {
        logger.info("Creating booking for flight ID: {}", request.getFlightId());
        
        Flight flight = flightRepository.findById(request.getFlightId())
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found"));
        
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        if (flight.getStatus() != FlightStatus.ACTIVE) {
            throw new InvalidRequestException("Flight is not available for booking");
        }
        
        if (flight.getAvailableSeats() < request.getNumberOfSeats()) {
            throw new InsufficientSeatsException("Only " + flight.getAvailableSeats() + " seats available");
        }
        
        if (request.getPassengers().size() != request.getNumberOfSeats()) {
            throw new InvalidRequestException("Number of passengers must match number of seats");
        }
        
        flight.setAvailableSeats(flight.getAvailableSeats() - request.getNumberOfSeats());
        flightRepository.save(flight);
        
        Booking booking = new Booking();
        booking.setPnr(generatePNR());
        booking.setUser(user);
        booking.setFlight(flight);
        booking.setNumberOfSeats(request.getNumberOfSeats());
        booking.setTotalAmount(flight.getFarePerSeat().multiply(new BigDecimal(request.getNumberOfSeats())));
        booking.setStatus(BookingStatus.PENDING);
        booking.setPaymentStatus(PaymentStatus.PENDING);
        
        Booking savedBooking = bookingRepository.save(booking);
        
        for (PassengerRequest passengerReq : request.getPassengers()) {
            Passenger passenger = new Passenger();
            passenger.setBooking(savedBooking);
            passenger.setName(passengerReq.getName());
            passenger.setAge(passengerReq.getAge());
            passenger.setGender(passengerReq.getGender());
            passenger.setIdProof(passengerReq.getIdProof());
            passenger.setIdProofNumber(passengerReq.getIdProofNumber());
            passengerRepository.save(passenger);
        }
        
        logger.info("Booking created successfully with PNR: {}", savedBooking.getPnr());
        return getBookingByPnr(savedBooking.getPnr());
    }
    
    public BookingResponse getBookingByPnr(String pnr) {
        logger.info("Fetching booking with PNR: {}", pnr);
        Booking booking = bookingRepository.findByPnr(pnr)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with PNR: " + pnr));
        return mapToBookingResponse(booking);
    }
    
    public BookingResponse getBookingById(Long id) {
        logger.info("Fetching booking with ID: {}", id);
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with ID: " + id));
        return mapToBookingResponse(booking);
    }
    
    public List<BookingResponse> getBookingsByUserId(Long userId) {
        logger.info("Fetching bookings for user ID: {}", userId);
        List<Booking> bookings = bookingRepository.findByUserId(userId);
        return bookings.stream()
                .map(this::mapToBookingResponse)
                .collect(Collectors.toList());
    }
    
    @Transactional
    public BookingResponse cancelBooking(Long bookingId) {
        logger.info("Cancelling booking with ID: {}", bookingId);
        
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));
        
        if (booking.getStatus() == BookingStatus.CANCELLED) {
            throw new InvalidRequestException("Booking is already cancelled");
        }
        
        Flight flight = booking.getFlight();
        flight.setAvailableSeats(flight.getAvailableSeats() + booking.getNumberOfSeats());
        flightRepository.save(flight);
        
        booking.setStatus(BookingStatus.CANCELLED);
        booking.setCancelledAt(LocalDateTime.now());
        if (booking.getPaymentStatus() == PaymentStatus.CONFIRMED) {
            booking.setPaymentStatus(PaymentStatus.REFUNDED);
        }
        
        Booking cancelledBooking = bookingRepository.save(booking);
        logger.info("Booking cancelled successfully with ID: {}", bookingId);
        
        return mapToBookingResponse(cancelledBooking);
    }
    
    @Transactional
    public BookingResponse confirmPayment(PaymentRequest request) {
        logger.info("Confirming payment for PNR: {}", request.getPnr());
        
        Booking booking = bookingRepository.findByPnr(request.getPnr())
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));
        
        if (booking.getStatus() == BookingStatus.CANCELLED) {
            throw new InvalidRequestException("Cannot process payment for cancelled booking");
        }
        
        booking.setPaymentStatus(PaymentStatus.CONFIRMED);
        booking.setStatus(BookingStatus.CONFIRMED);
        
        Booking confirmedBooking = bookingRepository.save(booking);
        logger.info("Payment confirmed for PNR: {}", request.getPnr());
        
        return mapToBookingResponse(confirmedBooking);
    }
    
    private String generatePNR() {
        return "PNR" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
    
    private BookingResponse mapToBookingResponse(Booking booking) {
        List<Passenger> passengers = passengerRepository.findByBookingId(booking.getId());
        List<PassengerResponse> passengerResponses = passengers.stream()
                .map(p -> new PassengerResponse(
                        p.getId(),
                        p.getName(),
                        p.getAge(),
                        p.getGender(),
                        p.getIdProof(),
                        p.getIdProofNumber()
                ))
                .collect(Collectors.toList());
        
        FlightResponse flightResponse = new FlightResponse(
                booking.getFlight().getId(),
                booking.getFlight().getFlightNumber(),
                booking.getFlight().getAirline(),
                booking.getFlight().getSourceAirport(),
                booking.getFlight().getDestinationAirport(),
                booking.getFlight().getDepartureTime(),
                booking.getFlight().getArrivalTime(),
                booking.getFlight().getTotalSeats(),
                booking.getFlight().getAvailableSeats(),
                booking.getFlight().getFarePerSeat(),
                booking.getFlight().getStatus(),
                null
        );
        
        return new BookingResponse(
                booking.getId(),
                booking.getPnr(),
                booking.getUser().getId(),
                booking.getUser().getName(),
                flightResponse,
                passengerResponses,
                booking.getNumberOfSeats(),
                booking.getTotalAmount(),
                booking.getStatus(),
                booking.getPaymentStatus(),
                booking.getBookingDate()
        );
    }
}