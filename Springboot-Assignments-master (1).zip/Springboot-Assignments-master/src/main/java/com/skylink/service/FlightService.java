package com.skylink.service;

import com.skylink.dto.*;
import com.skylink.entity.Flight;
import com.skylink.entity.FlightStatus;
import com.skylink.exception.DuplicateResourceException;
import com.skylink.exception.InvalidRequestException;
import com.skylink.exception.ResourceNotFoundException;
import com.skylink.repository.FlightRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FlightService {
    
    private static final Logger logger = LoggerFactory.getLogger(FlightService.class);
    
    @Autowired
    private FlightRepository flightRepository;
    
    @Transactional
    public FlightResponse addFlight(FlightRequest request) {
        logger.info("Adding new flight: {}", request.getFlightNumber());
        
        if (flightRepository.findByFlightNumber(request.getFlightNumber()).isPresent()) {
            throw new DuplicateResourceException("Flight already exists: " + request.getFlightNumber());
        }
        
        if (request.getArrivalTime().isBefore(request.getDepartureTime())) {
            throw new InvalidRequestException("Arrival time cannot be before departure time");
        }
        
        Flight flight = new Flight();
        flight.setFlightNumber(request.getFlightNumber());
        flight.setAirline(request.getAirline());
        flight.setSourceAirport(request.getSourceAirport());
        flight.setDestinationAirport(request.getDestinationAirport());
        flight.setDepartureTime(request.getDepartureTime());
        flight.setArrivalTime(request.getArrivalTime());
        flight.setTotalSeats(request.getTotalSeats());
        flight.setAvailableSeats(request.getTotalSeats());
        flight.setFarePerSeat(request.getFarePerSeat());
        flight.setStatus(FlightStatus.ACTIVE);
        
        Flight savedFlight = flightRepository.save(flight);
        logger.info("Flight added successfully with ID: {}", savedFlight.getId());
        
        return mapToFlightResponse(savedFlight);
    }
    
    @Transactional
    public FlightResponse updateFlight(Long id, FlightRequest request) {
        logger.info("Updating flight with ID: {}", id);
        Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found with ID: " + id));
        
        if (request.getArrivalTime().isBefore(request.getDepartureTime())) {
            throw new InvalidRequestException("Arrival time cannot be before departure time");
        }
        
        flight.setAirline(request.getAirline());
        flight.setSourceAirport(request.getSourceAirport());
        flight.setDestinationAirport(request.getDestinationAirport());
        flight.setDepartureTime(request.getDepartureTime());
        flight.setArrivalTime(request.getArrivalTime());
        flight.setFarePerSeat(request.getFarePerSeat());
        
        Flight updatedFlight = flightRepository.save(flight);
        logger.info("Flight updated successfully with ID: {}", updatedFlight.getId());
        
        return mapToFlightResponse(updatedFlight);
    }
    
    @Transactional
    public void deleteFlight(Long id) {
        logger.info("Deleting flight with ID: {}", id);
        Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found with ID: " + id));
        flightRepository.delete(flight);
        logger.info("Flight deleted successfully with ID: {}", id);
    }
    
    @Transactional
    public FlightResponse updateFlightStatus(Long id, FlightStatus status) {
        logger.info("Updating flight status for ID: {} to {}", id, status);
        Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found with ID: " + id));
        flight.setStatus(status);
        Flight updatedFlight = flightRepository.save(flight);
        logger.info("Flight status updated successfully");
        return mapToFlightResponse(updatedFlight);
    }
    
    public List<FlightResponse> getAllFlights() {
        logger.info("Fetching all flights");
        return flightRepository.findAll().stream()
                .map(this::mapToFlightResponse)
                .collect(Collectors.toList());
    }
    
    public FlightResponse getFlightById(Long id) {
        logger.info("Fetching flight with ID: {}", id);
        Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found with ID: " + id));
        return mapToFlightResponse(flight);
    }
    
    public List<FlightResponse> searchFlights(FlightSearchRequest request) {
        logger.info("Searching flights from {} to {} on {}", 
                request.getSource(), request.getDestination(), request.getJourneyDate());
        
        LocalDateTime dateTime = request.getJourneyDate().atStartOfDay();
        List<Flight> flights = flightRepository.searchFlights(
                request.getSource(),
                request.getDestination(),
                dateTime
        );
        
        if (request.getAirline() != null && !request.getAirline().isEmpty()) {
            flights = flights.stream()
                    .filter(f -> f.getAirline().equalsIgnoreCase(request.getAirline()))
                    .collect(Collectors.toList());
        }
        
        logger.info("Found {} flights matching criteria", flights.size());
        return flights.stream()
                .map(this::mapToFlightResponse)
                .collect(Collectors.toList());
    }
    
    private FlightResponse mapToFlightResponse(Flight flight) {
        long durationMinutes = Duration.between(
                flight.getDepartureTime(), 
                flight.getArrivalTime()
        ).toMinutes();
        
        return new FlightResponse(
                flight.getId(),
                flight.getFlightNumber(),
                flight.getAirline(),
                flight.getSourceAirport(),
                flight.getDestinationAirport(),
                flight.getDepartureTime(),
                flight.getArrivalTime(),
                flight.getTotalSeats(),
                flight.getAvailableSeats(),
                flight.getFarePerSeat(),
                flight.getStatus(),
                durationMinutes
        );
    }
}