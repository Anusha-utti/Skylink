package com.skylink.repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.skylink.entity.Flight;
import com.skylink.entity.FlightStatus;

@Repository
public interface FlightRepository extends JpaRepository<Flight, Long> {
    Optional<Flight> findByFlightNumber(String flightNumber);
    
    @Query("SELECT f FROM Flight f WHERE f.sourceAirport = :source " +
           "AND f.destinationAirport = :destination " +
           "AND DATE(f.departureTime) = DATE(:date) " +
           "AND f.status = 'ACTIVE' " +
           "AND f.availableSeats > 0")
    List<Flight> searchFlights(@Param("source") String source,
                                @Param("destination") String destination,
                                @Param("date") LocalDateTime date);
    
    List<Flight> findByStatus(FlightStatus status);
}