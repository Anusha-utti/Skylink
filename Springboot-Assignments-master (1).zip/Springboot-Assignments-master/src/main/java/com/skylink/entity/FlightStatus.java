package com.skylink.entity;

public enum FlightStatus {
    ACTIVE, DISABLED, CANCELLED
}