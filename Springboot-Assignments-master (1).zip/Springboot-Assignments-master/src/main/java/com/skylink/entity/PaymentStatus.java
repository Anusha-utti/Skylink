package com.skylink.entity;

public enum PaymentStatus {
    PENDING, CONFIRMED, FAILED, REFUNDED
}