package com.skylink.entity;

public enum UserRole {
    CUSTOMER, ADMIN
}