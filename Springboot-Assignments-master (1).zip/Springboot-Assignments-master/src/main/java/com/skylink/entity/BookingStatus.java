package com.skylink.entity;

public enum BookingStatus {
    PENDING, CONFIRMED, CANCELLED
}
