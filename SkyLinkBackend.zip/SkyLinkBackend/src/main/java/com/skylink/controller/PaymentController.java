package com.skylink.controller;

import com.skylink.entity.Payment;
import com.skylink.service.PaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping("/{bookingId}/confirm")
    public ResponseEntity<Payment> confirmPayment(@PathVariable Long bookingId) {
        Payment payment = paymentService.confirmPayment(bookingId);
        return ResponseEntity.ok(payment);
    }
}
