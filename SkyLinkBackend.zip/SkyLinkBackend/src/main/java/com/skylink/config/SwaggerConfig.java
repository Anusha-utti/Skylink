package com.skylink.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI skyLinkOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("SkyLink Flight Booking API")
                        .description("REST API documentation for SkyLink flight booking backend")
                        .version("1.0.0"));
    }
}
