package com.skylink.service.impl;

import com.skylink.entity.Booking;
import com.skylink.entity.Payment;
import com.skylink.exception.NotFoundException;
import com.skylink.repository.BookingRepository;
import com.skylink.repository.PaymentRepository;
import com.skylink.service.PaymentService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@Transactional
public class PaymentServiceImpl implements PaymentService {

    private final BookingRepository bookingRepository;
    private final PaymentRepository paymentRepository;

    public PaymentServiceImpl(BookingRepository bookingRepository,
                              PaymentRepository paymentRepository) {
        this.bookingRepository = bookingRepository;
        this.paymentRepository = paymentRepository;
    }

    @Override
    public Payment confirmPayment(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new NotFoundException("Booking not found"));

        Payment payment = new Payment();
        payment.setBooking(booking);
        payment.setAmount(booking.getTotalAmount());
        payment.setStatus(Payment.PaymentStatus.CONFIRMED);
        payment.setPaymentTime(LocalDateTime.now());
        Payment savedPayment = paymentRepository.save(payment);

        booking.setStatus(Booking.Status.CONFIRMED);
        bookingRepository.save(booking);

        return savedPayment;
    }
}
