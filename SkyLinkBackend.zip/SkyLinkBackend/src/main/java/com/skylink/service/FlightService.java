package com.skylink.service;

import com.skylink.dto.FlightResponse;
import com.skylink.entity.Flight;

import java.time.LocalDate;
import java.util.List;

public interface FlightService {

    List<FlightResponse> search(String source, String destination, LocalDate journeyDate);

    Flight createFlight(Flight flight);

    Flight updateFlight(Long id, Flight flight);

    void deleteFlight(Long id);

    List<Flight> getAllFlights();

    Flight enableDisableFlight(Long id, boolean active);
}
