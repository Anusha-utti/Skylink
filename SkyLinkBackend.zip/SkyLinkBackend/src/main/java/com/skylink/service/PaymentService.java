package com.skylink.service;

import com.skylink.entity.Payment;

public interface PaymentService {

    Payment confirmPayment(Long bookingId);
}
