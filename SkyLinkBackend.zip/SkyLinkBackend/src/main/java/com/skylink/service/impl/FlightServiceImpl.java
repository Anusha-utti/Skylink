package com.skylink.service.impl;

import com.skylink.dto.FlightResponse;
import com.skylink.entity.Flight;
import com.skylink.exception.NotFoundException;
import com.skylink.repository.FlightRepository;
import com.skylink.service.FlightService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class FlightServiceImpl implements FlightService {

    private final FlightRepository flightRepository;

    public FlightServiceImpl(FlightRepository flightRepository) {
        this.flightRepository = flightRepository;
    }

    @Override
    public List<FlightResponse> search(String source, String destination, LocalDate journeyDate) {
        LocalDateTime start = journeyDate.atStartOfDay();
        LocalDateTime end = journeyDate.atTime(23, 59, 59);

        return flightRepository.searchFlights(source, destination, start, end)
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public Flight createFlight(Flight flight) {
        flight.setAvailableSeats(flight.getTotalSeats());
        return flightRepository.save(flight);
    }

    @Override
    public Flight updateFlight(Long id, Flight flight) {
        Flight existing = flightRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Flight not found"));
        existing.setFlightNumber(flight.getFlightNumber());
        existing.setAirline(flight.getAirline());
        existing.setSourceAirport(flight.getSourceAirport());
        existing.setDestinationAirport(flight.getDestinationAirport());
        existing.setDepartureTime(flight.getDepartureTime());
        existing.setArrivalTime(flight.getArrivalTime());
        existing.setTotalSeats(flight.getTotalSeats());
        existing.setAvailableSeats(flight.getAvailableSeats());
        existing.setFarePerSeat(flight.getFarePerSeat());
        existing.setActive(flight.isActive());
        return flightRepository.save(existing);
    }

    @Override
    public void deleteFlight(Long id) {
        flightRepository.deleteById(id);
    }

    @Override
    public List<Flight> getAllFlights() {
        return flightRepository.findAll();
    }

    @Override
    public Flight enableDisableFlight(Long id, boolean active) {
        Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Flight not found"));
        flight.setActive(active);
        return flightRepository.save(flight);
    }

    private FlightResponse toResponse(Flight flight) {
        FlightResponse dto = new FlightResponse();
        dto.setId(flight.getId());
        dto.setFlightNumber(flight.getFlightNumber());
        dto.setAirline(flight.getAirline());
        dto.setSourceAirport(flight.getSourceAirport());
        dto.setDestinationAirport(flight.getDestinationAirport());
        dto.setDepartureTime(flight.getDepartureTime());
        dto.setArrivalTime(flight.getArrivalTime());
        dto.setAvailableSeats(flight.getAvailableSeats());
        dto.setFarePerSeat(flight.getFarePerSeat());

        if (flight.getDepartureTime() != null && flight.getArrivalTime() != null) {
            long minutes = Duration.between(flight.getDepartureTime(), flight.getArrivalTime()).toMinutes();
            dto.setDurationMinutes(minutes);
        }

        return dto;
    }
}
