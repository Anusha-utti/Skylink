package com.skylink.service;

import com.skylink.dto.UserRegistrationRequest;
import com.skylink.dto.UserResponse;
import com.skylink.entity.User;

public interface UserService {

    UserResponse register(UserRegistrationRequest request);

    UserResponse getUser(Long id);

    User authenticate(String email, String password);
}
