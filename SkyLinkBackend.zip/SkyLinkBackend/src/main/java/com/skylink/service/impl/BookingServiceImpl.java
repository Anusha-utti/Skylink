package com.skylink.service.impl;

import com.skylink.dto.BookingRequest;
import com.skylink.dto.BookingResponse;
import com.skylink.dto.PassengerRequest;
import com.skylink.entity.*;
import com.skylink.exception.BadRequestException;
import com.skylink.exception.NotFoundException;
import com.skylink.repository.*;
import com.skylink.service.BookingService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class BookingServiceImpl implements BookingService {

    private final UserRepository userRepository;
    private final FlightRepository flightRepository;
    private final BookingRepository bookingRepository;
    private final PassengerRepository passengerRepository;

    public BookingServiceImpl(UserRepository userRepository,
                              FlightRepository flightRepository,
                              BookingRepository bookingRepository,
                              PassengerRepository passengerRepository) {
        this.userRepository = userRepository;
        this.flightRepository = flightRepository;
        this.bookingRepository = bookingRepository;
        this.passengerRepository = passengerRepository;
    }

    @Override
    public BookingResponse createBooking(BookingRequest request) {
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new NotFoundException("User not found"));

        Flight flight = flightRepository.findById(request.getFlightId())
                .orElseThrow(() -> new NotFoundException("Flight not found"));

        if (!flight.isActive()) {
            throw new BadRequestException("Flight is not active");
        }

        int seatsRequested = request.getSeats();
        if (seatsRequested <= 0) {
            throw new BadRequestException("Seats must be greater than 0");
        }

        if (flight.getAvailableSeats() < seatsRequested) {
            throw new BadRequestException("Not enough seats available");
        }

        flight.setAvailableSeats(flight.getAvailableSeats() - seatsRequested);

        Booking booking = new Booking();
        booking.setCustomer(user);
        booking.setFlight(flight);
        booking.setSeatsBooked(seatsRequested);
        booking.setTotalAmount(flight.getFarePerSeat() * seatsRequested);
        booking.setPnr(generatePnr());

        List<Passenger> passengers = Optional.ofNullable(request.getPassengers())
                .orElse(Collections.emptyList())
                .stream()
                .map(pr -> toPassenger(pr, booking))
                .collect(Collectors.toList());

        booking.setPassengers(passengers);

        Booking saved = bookingRepository.save(booking);

        return toResponse(saved);
    }

    @Override
    public BookingResponse getBookingById(Long id) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Booking not found"));
        return toResponse(booking);
    }

    @Override
    public BookingResponse getBookingByPnr(String pnr) {
        Booking booking = bookingRepository.findByPnr(pnr)
                .orElseThrow(() -> new NotFoundException("Booking not found"));
        return toResponse(booking);
    }

    @Override
    public List<BookingResponse> getBookingsByUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException("User not found"));
        return bookingRepository.findByCustomer(user)
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public BookingResponse cancelBooking(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new NotFoundException("Booking not found"));

        if (booking.getStatus() == Booking.Status.CANCELLED) {
            throw new BadRequestException("Booking already cancelled");
        }

        booking.setStatus(Booking.Status.CANCELLED);

        Flight flight = booking.getFlight();
        flight.setAvailableSeats(flight.getAvailableSeats() + booking.getSeatsBooked());

        Booking saved = bookingRepository.save(booking);
        return toResponse(saved);
    }

    private Passenger toPassenger(PassengerRequest pr, Booking booking) {
        Passenger p = new Passenger();
        p.setFullName(pr.getFullName());
        p.setAge(pr.getAge());
        p.setGender(pr.getGender());
        p.setIdProofType(pr.getIdProofType());
        p.setIdProofNumber(pr.getIdProofNumber());
        p.setBooking(booking);
        return p;
    }

    private String generatePnr() {
        return "SKY" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    private BookingResponse toResponse(Booking booking) {
        BookingResponse dto = new BookingResponse();
        dto.setBookingId(booking.getId());
        dto.setPnr(booking.getPnr());
        dto.setBookingStatus(booking.getStatus().name());
        dto.setFlightId(booking.getFlight().getId());
        dto.setUserId(booking.getCustomer().getId());
        dto.setSeatsBooked(booking.getSeatsBooked());
        dto.setTotalAmount(booking.getTotalAmount());
        return dto;
    }
}
