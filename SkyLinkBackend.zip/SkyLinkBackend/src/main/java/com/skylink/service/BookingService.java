package com.skylink.service;

import com.skylink.dto.BookingRequest;
import com.skylink.dto.BookingResponse;

import java.util.List;

public interface BookingService {

    BookingResponse createBooking(BookingRequest request);

    BookingResponse getBookingById(Long id);

    BookingResponse getBookingByPnr(String pnr);

    List<BookingResponse> getBookingsByUser(Long userId);

    BookingResponse cancelBooking(Long bookingId);
}
