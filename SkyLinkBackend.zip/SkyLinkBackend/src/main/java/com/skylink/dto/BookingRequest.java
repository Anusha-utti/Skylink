package com.skylink.dto;

import jakarta.validation.constraints.NotNull;
import java.util.List;

public class BookingRequest {

    @NotNull
    private Long userId;

    @NotNull
    private Long flightId;

    @NotNull
    private Integer seats;

    private List<PassengerRequest> passengers;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getFlightId() {
        return flightId;
    }

    public void setFlightId(Long flightId) {
        this.flightId = flightId;
    }

    public Integer getSeats() {
        return seats;
    }

    public void setSeats(Integer seats) {
        this.seats = seats;
    }

    public List<PassengerRequest> getPassengers() {
        return passengers;
    }

    public void setPassengers(List<PassengerRequest> passengers) {
        this.passengers = passengers;
    }
}
