package com.example.catalog.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.catalog.entity.Tone;

@Repository
public interface ToneRepository extends JpaRepository<Tone, Long> {
    List<Tone> findByCategory(String category);
}
