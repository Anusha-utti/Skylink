package com.example.catalog.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.catalog.entity.Tone;
import com.example.catalog.repository.ToneRepository;

@RestController
@RequestMapping("/api/catalog")
public class CatalogController {

    @Autowired
    private ToneRepository toneRepository;

    @GetMapping("/tones")
    public List<Tone> getAllTones() {
        return toneRepository.findAll();
    }
    @PostMapping("/tones")
public Tone addTone(@RequestBody Tone tone) {
    return toneRepository.save(tone);
}

    @GetMapping("/tones/{id}")
    public Tone getToneById(@PathVariable Long id) {
        return toneRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Tone not found"));
    }
}
