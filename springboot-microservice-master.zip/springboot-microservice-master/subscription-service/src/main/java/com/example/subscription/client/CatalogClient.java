package com.example.subscription.client;

import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "catalogue-service", url = "http://localhost:8082/api/catalog")
public interface CatalogClient {

    @GetMapping("/tones/{id}")
    Map<String, Object> getToneById(@PathVariable("id") Long id);

    @GetMapping("/tones")
    List<Map<String, Object>> getAllTones();
}
