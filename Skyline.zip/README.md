# SkyLink - Flight Booking REST API (Spring Boot)

## Overview
Minimal Spring Boot project demonstrating:
- User management, Flight management, Booking (with seat checks), simulated payment
- H2 in-memory DB for quick run (switchable to MySQL/Postgres in `application.properties`)
- Basic validation and centralized exception handling
- OpenAPI UI available at `/swagger-ui.html` (springdoc)

## Run
```
mvn clean package
java -jar target/skylink-0.0.1-SNAPSHOT.jar
```

## Notes
This is a minimal working backend scaffold. Customize, add security, and improve concurrency/transaction handling for production.
