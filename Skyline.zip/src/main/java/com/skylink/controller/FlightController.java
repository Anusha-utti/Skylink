package com.skylink.controller;

import com.skylink.entity.Flight;
import com.skylink.service.FlightService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.time.LocalDateTime;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/flights")
public class FlightController {
    private final FlightService svc;
    public FlightController(FlightService svc){this.svc=svc;}

    @PostMapping
    public ResponseEntity<Flight> add(@Valid @RequestBody Flight f){ return ResponseEntity.ok(svc.save(f)); }

    @GetMapping
    public ResponseEntity<List<Flight>> all(){ return ResponseEntity.ok(svc.findAll()); }

    @GetMapping("/search")
    public ResponseEntity<List<Flight>> search(@RequestParam String source,
                                               @RequestParam String destination,
                                               @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date){
        LocalDateTime dt = date.atStartOfDay();
        return ResponseEntity.ok(svc.search(source,destination,dt));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){ svc.delete(id); return ResponseEntity.noContent().build(); }
}
