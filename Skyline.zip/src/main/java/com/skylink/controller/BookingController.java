package com.skylink.controller;

import com.skylink.entity.Booking;
import com.skylink.service.BookingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {
    private final BookingService svc;
    public BookingController(BookingService svc){this.svc=svc;}

    public static class CreateReq {
        public Long userId;
        public Long flightId;
        public int seats;
        public List<Map<String,String>> passengers;
    }

    @PostMapping
    public ResponseEntity<Booking> create(@RequestBody CreateReq req){
        Booking b = svc.createBooking(req.userId, req.flightId, req.seats, req.passengers);
        return ResponseEntity.ok(b);
    }

    @GetMapping("/{pnr}")
    public ResponseEntity<Booking> get(@PathVariable String pnr){
        return svc.findByPnr(pnr).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/by-customer/{customerId}")
    public ResponseEntity<List<Booking>> listByCustomer(@PathVariable Long customerId){
        return ResponseEntity.ok(svc.findByCustomer(customerId));
    }

    @DeleteMapping("/{pnr}")
    public ResponseEntity<Booking> cancel(@PathVariable String pnr){
        Booking b = svc.cancel(pnr);
        return ResponseEntity.ok(b);
    }
}
