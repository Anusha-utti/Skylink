package com.skylink.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "flights")
public class Flight {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true) private String flightNumber;
    private String airline;
    private String source;
    private String destination;
    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;
    private int totalSeats;
    private int availableSeats;
    private double fare;
    private boolean enabled = true;

    @PrePersist
    public void prePersist(){ if (availableSeats==0) availableSeats = totalSeats; }

    // getters/setters
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public String getFlightNumber(){return flightNumber;}
    public void setFlightNumber(String f){this.flightNumber=f;}
    public String getAirline(){return airline;}
    public void setAirline(String a){this.airline=a;}
    public String getSource(){return source;}
    public void setSource(String s){this.source=s;}
    public String getDestination(){return destination;}
    public void setDestination(String d){this.destination=d;}
    public LocalDateTime getDepartureTime(){return departureTime;}
    public void setDepartureTime(LocalDateTime dt){this.departureTime=dt;}
    public LocalDateTime getArrivalTime(){return arrivalTime;}
    public void setArrivalTime(LocalDateTime at){this.arrivalTime=at;}
    public int getTotalSeats(){return totalSeats;}
    public void setTotalSeats(int t){this.totalSeats=t;}
    public int getAvailableSeats(){return availableSeats;}
    public void setAvailableSeats(int a){this.availableSeats=a;}
    public double getFare(){return fare;}
    public void setFare(double f){this.fare=f;}
    public boolean isEnabled(){return enabled;}
    public void setEnabled(boolean e){this.enabled=e;}
}
