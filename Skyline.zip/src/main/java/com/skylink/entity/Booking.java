package com.skylink.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.*;

@Entity
@Table(name = "bookings")
public class Booking {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true) private String pnr;
    @ManyToOne private User customer;
    @ManyToOne private Flight flight;
    private int seatsBooked;
    private LocalDateTime createdAt = LocalDateTime.now();
    private String status; // CREATED, CONFIRMED, CANCELLED

    @ElementCollection
    @CollectionTable(name="booking_passengers", joinColumns=@JoinColumn(name="booking_id"))
    private List<Map<String,String>> passengers = new ArrayList<>();

    // getters/setters
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public String getPnr(){return pnr;}
    public void setPnr(String p){this.pnr=p;}
    public User getCustomer(){return customer;}
    public void setCustomer(User c){this.customer=c;}
    public Flight getFlight(){return flight;}
    public void setFlight(Flight f){this.flight=f;}
    public int getSeatsBooked(){return seatsBooked;}
    public void setSeatsBooked(int s){this.seatsBooked=s;}
    public LocalDateTime getCreatedAt(){return createdAt;}
    public void setCreatedAt(LocalDateTime t){this.createdAt=t;}
    public String getStatus(){return status;}
    public void setStatus(String s){this.status=s;}
    public List<Map<String,String>> getPassengers(){return passengers;}
    public void setPassengers(List<Map<String,String>> p){this.passengers=p;}
}
