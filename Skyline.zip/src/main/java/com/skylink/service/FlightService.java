package com.skylink.service;

import com.skylink.entity.Flight;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface FlightService {
    Flight save(Flight f);
    Optional<Flight> findById(Long id);
    List<Flight> search(String source, String destination, LocalDateTime date);
    List<Flight> findAll();
    void delete(Long id);
}
