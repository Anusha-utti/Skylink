package com.skylink.service.impl;

import com.skylink.entity.Booking;
import com.skylink.entity.Flight;
import com.skylink.entity.User;
import com.skylink.repository.BookingRepository;
import com.skylink.repository.FlightRepository;
import com.skylink.repository.UserRepository;
import com.skylink.service.BookingService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class BookingServiceImpl implements BookingService {
    private final BookingRepository bookingRepo;
    private final FlightRepository flightRepo;
    private final UserRepository userRepo;

    public BookingServiceImpl(BookingRepository bookingRepo, FlightRepository flightRepo, UserRepository userRepo){
        this.bookingRepo=bookingRepo; this.flightRepo=flightRepo; this.userRepo=userRepo;
    }

    @Override
    @Transactional
    public Booking createBooking(Long userId, Long flightId, int seats, List<Map<String,String>> passengers){
        User user = userRepo.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        Flight flight = flightRepo.findById(flightId).orElseThrow(() -> new RuntimeException("Flight not found"));
        if(!flight.isEnabled()) throw new RuntimeException("Flight not available");
        if(flight.getAvailableSeats() < seats) throw new RuntimeException("Insufficient seats");

        // lock seats (simple approach)
        flight.setAvailableSeats(flight.getAvailableSeats() - seats);
        flightRepo.save(flight);

        Booking b = new Booking();
        b.setCustomer(user);
        b.setFlight(flight);
        b.setSeatsBooked(seats);
        b.setPassengers(passengers);
        b.setStatus("CONFIRMED");
        b.setPnr(UUID.randomUUID().toString().substring(0,8).toUpperCase());
        return bookingRepo.save(b);
    }

    @Override public Optional<Booking> findByPnr(String pnr){ return bookingRepo.findByPnr(pnr); }
    @Override public List<Booking> findByCustomer(Long customerId){ return bookingRepo.findByCustomerId(customerId); }

    @Override
    @Transactional
    public Booking cancel(String pnr){
        Booking b = bookingRepo.findByPnr(pnr).orElseThrow(() -> new RuntimeException("Booking not found"));
        if("CANCELLED".equals(b.getStatus())) throw new RuntimeException("Already cancelled");
        Flight flight = b.getFlight();
        flight.setAvailableSeats(flight.getAvailableSeats() + b.getSeatsBooked());
        flightRepo.save(flight);
        b.setStatus("CANCELLED");
        return bookingRepo.save(b);
    }
}
