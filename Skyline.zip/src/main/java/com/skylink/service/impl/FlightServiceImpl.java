package com.skylink.service.impl;

import com.skylink.entity.Flight;
import com.skylink.repository.FlightRepository;
import com.skylink.service.FlightService;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class FlightServiceImpl implements FlightService {
    private final FlightRepository repo;
    public FlightServiceImpl(FlightRepository repo){this.repo=repo;}
    @Override public Flight save(Flight f){ return repo.save(f); }
    @Override public Optional<Flight> findById(Long id){ return repo.findById(id); }
    @Override public List<Flight> findAll(){ return repo.findAll(); }
    @Override public void delete(Long id){ repo.deleteById(id); }
    @Override public List<Flight> search(String source, String destination, LocalDateTime date){
        LocalDateTime start = date.withHour(0).withMinute(0).withSecond(0).withNano(0);
        LocalDateTime end = start.plusDays(1);
        return repo.findBySourceAndDestinationAndDepartureTimeBetweenAndEnabled(source,destination,start,end,true);
    }
}
