package com.skylink.service;

import com.skylink.entity.Booking;
import com.skylink.entity.User;
import java.util.List;
import java.util.Optional;

public interface BookingService {
    Booking createBooking(Long userId, Long flightId, int seats, java.util.List<java.util.Map<String,String>> passengers);
    Optional<Booking> findByPnr(String pnr);
    List<Booking> findByCustomer(Long customerId);
    Booking cancel(String pnr);
}
