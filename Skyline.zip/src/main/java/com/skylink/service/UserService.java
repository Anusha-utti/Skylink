package com.skylink.service;

import com.skylink.entity.User;
import java.util.Optional;

public interface UserService {
    User register(User user);
    Optional<User> findById(Long id);
    Optional<User> findByEmail(String email);
}
