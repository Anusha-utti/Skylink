package com.skylink.exception;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Object> handleRuntime(RuntimeException ex, WebRequest req){
        return new ResponseEntity<>(java.util.Map.of("error", ex.getMessage()), HttpStatus.BAD_REQUEST);
    }
}
